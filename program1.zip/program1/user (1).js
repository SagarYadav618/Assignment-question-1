
document.querySelector("#search").addEventListener("click",function(){
    let username = document.getElementById("username").value;
    fetch('https://api.github.com/users/'+ username)
    .then((response) => {
        if (response.ok) {
          return response.json();
        } else {
          throw new Error('Something went wrong');
        }
      })
  .then(data =>{
      
    console.log(data);
    document.getElementById("login").innerHTML = data.login;
    document.getElementById("img").src = data.avatar_url;
    document.getElementById("type").innerHTML = data.type;
    document.getElementById("login").innerHTML = data.login;
  


  })
    .catch(error=>{
    console.log("error" +error);
});

  
})
